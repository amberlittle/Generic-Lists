import java.util.Iterator;

public interface CreateIterator<I> {

    abstract Iterator<I> createIterator();

}
