// netid: alittl9
// uin: 657025940

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello generic lists");
	}

}
